#include "../../include/transform/Transformation.h"


char* Transformation::parse_arguments(char* arg_array) {
    return arg_array;
}

Transformation::~Transformation() {}
